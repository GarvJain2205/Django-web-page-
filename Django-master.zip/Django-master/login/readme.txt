This is program is the combination of signup and login screen Please follow along my video tutorial to learn 
how to login and register a user

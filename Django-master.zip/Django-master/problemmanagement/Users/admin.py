from django.contrib import admin
from .models import information

admin.site.register(information)

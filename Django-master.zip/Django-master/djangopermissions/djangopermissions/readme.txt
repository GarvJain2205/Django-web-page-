This is the project folder with settings and urls
